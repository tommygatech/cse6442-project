Project Installation and Setup Instructions
This document provides the steps to install the required dependencies and set up the project, including running the UI using a local web server. The python code should detect and install required libraries. 
### 1. Install Required Python Libraries
Before running the project, make sure you have the required Python libraries installed. Use the following `pip` commands to install the dependencies:
pip install pandas openpyxl
pip install numpy
pip install requests
pip install scikit-learn
pip install pmdarima
pip install tqdm
Install Missing Dependencies
If any of the libraries above are missing or not installed, you can install them by running the commands listed. The following libraries are needed for the core functionality and UI:
* pandas for data manipulation
* openpyxl for reading and writing Excel files
* numpy for numerical operations
* requests for making HTTP requests
* scikit-learn for machine learning models
* pmdarima for time series forecasting
* tqdm for progress bars during execution
If any of these are missing, run the respective pip install commands as in section 1.
Run the UI 
If you would like to view the user interface for the project, you can run the local Python web server from the UI folder. Follow these steps:
1. Navigate to the UI folder in your project directory.
2. Run the following command to start the web server:pythonwebserver.bat
3. Navigate to http://localhost:8000 or your python server port to view the UI.

