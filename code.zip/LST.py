# pip install pandas openpyxl
import requests
import json
import prettytable
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import SparkSession
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press F9 to toggle the breakpoint.


def get_data_from_bls(seriesID, startYr, endYr, bls_key, industry_name, state):
    headers = {'Content-type': 'application/json'}
    bls_api_url = 'https://api.bls.gov/publicAPI/v2/timeseries/data/'

    data = json.dumps({
        "seriesid": [seriesID],
        "startyear": startYr,
        "endyear": endYr,
        "registrationKey": bls_key
    })

    series_list = []

    p = requests.post(bls_api_url, data=data, headers=headers)

    if p.status_code != 200:
        raise Exception(f"Error: {p.status_code}, {p.text}")

    json_data = json.loads(p.text)

    for series in json_data['Results']['series']:
        seriesId = series['seriesID']
        for item in series['data']:
            year = item['year']
            period = item['periodName']
            value = item['value']

            if 'M01' <= period <= 'M12':
                series_list.append([seriesId, state, industry_name, year, period, value])

    return series_list


def create_lstm_model(input_shape):
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=input_shape),
        tf.keras.layers.LSTM(50, return_sequences=True),
        tf.keras.layers.LSTM(25),
        tf.keras.layers.Dense(1)
    ])
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model


def train_model_and_predict(data,number_of_month):
    # Sample Time Series Data: Generate a DataFrame for multiple professions
    #number_of_month = 24

    #date_range = pd.date_range(start='2024-01-01', periods=number_of_month, freq='ME')

    # Generate random job postings and growth rates
    '''
    data = {'Date': np.tile(date_range, len(professions) * len(states)),
        'Profession': np.repeat(professions, len(date_range) * len(states)),
        'State': np.tile(states, len(professions) * len(date_range)),
        'Job_Postings': np.random.randint(1000, 5000, size=(len(professions) * len(states) * len(date_range),)),
        'Growth_Rate': np.random.uniform(0.01, 0.2,
        size=(len(professions) * len(states) * len(date_range),))
    }
    '''

    #df = pd.DataFrame(data)

    # Calculate Hot Profession Score

    data.set_index('seriesID', inplace=True)
    states = data['state'].unique()
    professions = data['industry_name'].unique()
    data['Hot_Profession_Score'] = data['value'] * np.random.uniform(0.01, 0.2, size=len(data))
    # Store predictions
    predictions = []
    future_predictions = []
    # Train and predict for each profession in each state
    for state in states:
        for profession in professions:
            # Filter data
            filtered_data = data[(data['industry_name'] == profession) & (data['state'] == state)][['Hot_Profession_Score']]
            #filtered_data = data[(data['state'] == state)][['Hot_Profession_Score']]
            if filtered_data.empty:
                continue
            '''lst'''
            # Prepare the dataset

            time_step = 3
            X, y = [], []
            scaler = MinMaxScaler()
            scaled_data = scaler.fit_transform(filtered_data)
            for i in range(len(scaled_data) - time_step - 1):
                X.append(scaled_data[i:(i + time_step), 0])
                y.append(scaled_data[i + time_step, 0])
            X, y = np.array(X), np.array(y)
            X = X.reshape(X.shape[0], X.shape[1], 1)

            # Create and train the LSTM model
            model = create_lstm_model(input_shape=(X.shape[1], 1))
            model.fit(X, y, epochs=5, batch_size=1, verbose=0)

            # Make predictions for the next 5 years (60 months)

            last_sequence = scaled_data[-time_step:].reshape(1, time_step, 1)

            for _ in range(number_of_month):  # Predict 60 months ahead
                next_prediction = model.predict(last_sequence)
                #next_prediction = model.predict(X_test)
                future_predictions.append(next_prediction[0, 0])
                last_sequence = np.append(last_sequence[:, 1:, :], next_prediction.reshape(1, 1, 1), axis=1)

            future_predictions = scaler.inverse_transform(np.array(future_predictions).reshape(-1, 1))


    predictions_df = pd.DataFrame(future_predictions, columns=['State', 'Profession', 'Avg_Score'])

    # Sort and get the top 5 hottest jobs for each state
    top_hottest_jobs = predictions_df.sort_values(by=['State', 'Avg_Score'], ascending=[True, False])
    top_5_jobs = top_hottest_jobs.groupby('State').head(10)


    # Save the results to a CSV file
    top_5_jobs.to_csv(f"{number_of_month}_hottest_jobs_by_state.csv", index=False)
    print("Top 5 hottest jobs for each state saved to 'hottest_jobs_by_state.csv'.")


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('Team 90')

    df_bls_combined =pd.read_csv('professionsoutput.csv')
    train_model_and_predict(df_bls_combined,12)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
